<?php
require_once __DIR__.'/mahasiswa_helper.php';require_once __DIR__.'/csrf.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: mahasiswa.php');exit;}
try{csrf_verify();$id=(int)($_POST['id_mahasiswa']??0);if($id<=0)throw new RuntimeException('ID mahasiswa tidak valid.');$r=mhs_soa_call('delete',['id_mahasiswa'=>$id]);if(!empty($r['error']))throw new RuntimeException(mhs_soa_message($r,'Data mahasiswa gagal dihapus.'));$_SESSION['success']=mhs_soa_message($r,'Data mahasiswa berhasil dihapus.');}catch(Throwable $e){$_SESSION['error']=$e->getMessage();}
header('Location: mahasiswa.php');exit;
