<?php
/** Helper SOA Consumer untuk CRUD Mahasiswa. Tidak mengakses database langsung. */
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/api_client.php';
wajib_role(['ADMIN']);
function mhs_soa_call(string $action,array $payload=[]): array {
 $payload['action']=$action;$payload['id_pengguna']=(int)($_SESSION['id_pengguna']??0);
 $r=soa_request('apimahasiswa.php',$payload);
 if(!empty($r['error'])) return $r;
 if(empty($r['data']['success'])) return ['http_code'=>$r['http_code'],'data'=>$r['data'],'error'=>$r['data']['message']??'Permintaan ke Provider gagal.'];
 return $r;
}
function mhs_soa_data(array $r,string $key) { return $r['data']['data'][$key]??[]; }
function mhs_soa_message(array $r,string $fallback): string { return (string)($r['data']['message']??$r['error']??$fallback); }
function mhs_h($v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function mhs_program_studi_list(): array { $r=mhs_soa_call('options');return mhs_soa_data($r,'program_studi'); }
