<?php
require_once __DIR__.'/mahasiswa_helper.php';
require_once __DIR__.'/csrf.php';
$r=mhs_soa_call('list');$rows=mhs_soa_data($r,'mahasiswa');$error=!empty($r['error'])?mhs_soa_message($r,'Gagal mengambil data mahasiswa.'):'';
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Mahasiswa - SIM Mahasiswa</title><link rel="stylesheet" href="style.css"></head><body class="app-body">
<?php include __DIR__.'/topbar.php';include __DIR__.'/sideleftbar.php';?><main class="main-content">
<div class="page-heading page-heading-flex"><div><span class="eyebrow">MASTER DATA</span><h1>Mahasiswa</h1><p>Kelola data induk mahasiswa melalui layanan SOA.</p></div><a href="mahasiswa_tambah.php" class="btn btn-primary">+ Tambah Mahasiswa</a></div>
<?php foreach(['success'=>'success','error'=>'danger'] as $k=>$v):if(!empty($_SESSION[$k])):?><div class="alert alert-<?= $v ?>"><?= mhs_h($_SESSION[$k]) ?></div><?php unset($_SESSION[$k]);endif;endforeach;?>
<?php if($error):?><div class="alert alert-danger"><?=mhs_h($error)?></div><?php endif;?>
<div class="dashboard-panel"><div class="table-responsive"><table class="data-table"><thead><tr><th>No.</th><th>NPM</th><th>Nama Mahasiswa</th><th>Program Studi</th><th>Fakultas</th><th>Jenis Kelamin</th><th>Tanggal Masuk</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
<?php if($rows):$n=1;foreach($rows as $x):?><tr><td><?=$n++?></td><td><strong><?=mhs_h($x['npm'])?></strong></td><td><?=mhs_h($x['nama_mahasiswa'])?></td><td><?=mhs_h(($x['jenjang']??'').' - '.($x['nama_program_studi']??''))?></td><td><?=mhs_h($x['nama_fakultas']??'')?></td><td><?=($x['jenis_kelamin']??'')==='L'?'Laki-laki':'Perempuan'?></td><td><?=mhs_h($x['tanggal_masuk'])?></td><td><?=mhs_h($x['status_mahasiswa'])?></td><td><div class="action-group"><a class="btn btn-sm btn-outline" href="mahasiswa_edit.php?id=<?=(int)$x['id_mahasiswa']?>">Edit</a><form method="post" action="mahasiswa_hapus.php" onsubmit="return confirm('Hapus data mahasiswa ini?')"><?=csrf_field()?><input type="hidden" name="id_mahasiswa" value="<?=(int)$x['id_mahasiswa']?>"><button class="btn btn-sm btn-danger">Hapus</button></form></div></td></tr><?php endforeach;?><?php else:?><tr><td colspan="9" class="empty-state"><?=$error?'Data belum dapat dimuat dari Provider SOA.':'Belum ada data mahasiswa.'?></td></tr><?php endif;?>
</tbody></table></div></div></main></body></html>
