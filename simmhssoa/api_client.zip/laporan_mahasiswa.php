<?php
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/api_client.php';

wajib_role(['ADMIN', 'OPERATOR_PRODI', 'DEKANAT', 'REKTORAT', 'MAHASISWA']);

function e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$role = (string)($_SESSION['kode_role'] ?? '');
$id_pengguna_session = (int)($_SESSION['id_pengguna'] ?? 0);

$filter_fakultas = filter_input(INPUT_GET, 'id_fakultas', FILTER_VALIDATE_INT) ?: 0;
$filter_prodi = filter_input(INPUT_GET, 'id_program_studi', FILTER_VALIDATE_INT) ?: 0;
$filter_status = trim((string)($_GET['status_mahasiswa'] ?? ''));
$filter_jk = trim((string)($_GET['jenis_kelamin'] ?? ''));
$keyword = trim((string)($_GET['q'] ?? ''));

$statuses = ['Aktif', 'Cuti', 'Lulus', 'Mengundurkan Diri', 'Drop Out', 'Tidak Aktif'];
$jenis_kelamin_options = ['L' => 'Laki-laki', 'P' => 'Perempuan'];
if (!in_array($filter_status, $statuses, true)) $filter_status = '';
if (!array_key_exists($filter_jk, $jenis_kelamin_options)) $filter_jk = '';

$api = soa_request('apilaporanmahasiswa.php', [
    'id_pengguna' => $id_pengguna_session,
    'id_fakultas' => $filter_fakultas,
    'id_program_studi' => $filter_prodi,
    'status_mahasiswa' => $filter_status,
    'jenis_kelamin' => $filter_jk,
    'q' => $keyword
]);

$apiBody = $api['data'] ?? [];
if (($api['error'] ?? null) !== null || (int)($api['http_code'] ?? 0) !== 200 || empty($apiBody['success'])) {
    error_log('SOA laporan mahasiswa: '.($api['error'] ?? ($apiBody['message'] ?? 'Respons API tidak valid')));
    $_SESSION['error'] = $apiBody['message'] ?? 'Layanan laporan mahasiswa tidak dapat dihubungi.';
    $fakultas = $prodi = $rows = [];
    $total = $total_l = $total_p = $total_aktif = $total_lulus = 0;
} else {
    $data = $apiBody['data'] ?? [];
    $fakultas = $data['fakultas'] ?? [];
    $prodi = $data['program_studi'] ?? [];
    $rows = $data['mahasiswa'] ?? [];
    $summary = $data['summary'] ?? [];
    $total = (int)($summary['total'] ?? count($rows));
    $total_l = (int)($summary['total_l'] ?? 0);
    $total_p = (int)($summary['total_p'] ?? 0);
    $total_aktif = (int)($summary['total_aktif'] ?? 0);
    $total_lulus = (int)($summary['total_lulus'] ?? 0);
    $filters = $data['filters'] ?? [];
    $filter_fakultas = (int)($filters['id_fakultas'] ?? $filter_fakultas);
    $filter_prodi = (int)($filters['id_program_studi'] ?? $filter_prodi);
    $filter_status = (string)($filters['status_mahasiswa'] ?? $filter_status);
    $filter_jk = (string)($filters['jenis_kelamin'] ?? $filter_jk);
    $keyword = (string)($filters['q'] ?? $keyword);
}

$judul_scope = 'Seluruh Data Mahasiswa';
if ($role === 'OPERATOR_PRODI') $judul_scope = 'Program Studi Anda';
elseif ($role === 'DEKANAT') $judul_scope = 'Fakultas Anda';
elseif ($role === 'REKTORAT') $judul_scope = 'Universitas Anda';
elseif ($role === 'MAHASISWA') $judul_scope = 'Data Saya';

$query_string = http_build_query([
    'id_fakultas' => $filter_fakultas ?: null,
    'id_program_studi' => $filter_prodi ?: null,
    'status_mahasiswa' => $filter_status ?: null,
    'jenis_kelamin' => $filter_jk ?: null,
    'q' => $keyword ?: null,
]);
$print_url = 'laporan_mahasiswa.php' . ($query_string !== '' ? '?' . $query_string : '');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Laporan Mahasiswa - SIM Mahasiswa</title>
    <link rel="stylesheet" href="style.css">

    <style>
        .report-panel{background:#fff;border:1px solid #e5e7eb;border-radius:14px;box-shadow:0 4px 18px rgba(0,0,0,.04);overflow:hidden;margin-bottom:20px}
        .report-header{padding:22px 24px;border-bottom:1px solid #e5e7eb}
        .report-header h2{margin:0 0 5px;font-size:20px}
        .report-header p{margin:0;color:#6b7280;font-size:13px}
        .filter-form{padding:20px 24px}
        .filter-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:15px}
        .filter-group label{display:block;margin-bottom:7px;font-size:12px;font-weight:700;color:#374151}
        .filter-group input,.filter-group select{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;background:#fff;font:inherit}
        .filter-actions{display:flex;gap:10px;align-items:center;margin-top:16px}
        .summary-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:15px;margin-bottom:20px}
        .summary-card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:18px 20px;box-shadow:0 4px 18px rgba(0,0,0,.04)}
        .summary-card .label{font-size:12px;color:#6b7280;margin-bottom:6px}
        .summary-card .value{font-size:25px;font-weight:800;color:#111827}
        .report-table-wrap{overflow-x:auto}
        .report-table{width:100%;border-collapse:collapse;min-width:900px}
        .report-table th,.report-table td{padding:11px 13px;border-bottom:1px solid #e5e7eb;text-align:left;font-size:13px;vertical-align:top}
        .report-table th{background:#f8fafc;color:#374151;font-size:12px;white-space:nowrap}
        .report-table td.center,.report-table th.center{text-align:center}
        .report-footer{padding:14px 20px;color:#6b7280;font-size:12px;border-top:1px solid #e5e7eb}
        .scope-badge{display:inline-block;padding:5px 9px;border-radius:999px;background:#f3f4f6;color:#374151;font-size:11px;font-weight:700}
        .status-badge{display:inline-block;padding:4px 8px;border-radius:999px;background:#f3f4f6;font-size:11px}
        .print-only{display:none}
        @media(max-width:1000px){
            .filter-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
            .summary-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
        }
        @media(max-width:600px){
            .filter-grid,.summary-grid{grid-template-columns:1fr}
            .filter-actions{flex-direction:column;align-items:stretch}
            .filter-actions .btn{width:100%;box-sizing:border-box;text-align:center}
        }
        @media print{
            @page{size:A4 landscape;margin:12mm}
            body{background:#fff!important}
            .topbar,.sidebar,.side-leftbar,.filter-panel,.no-print{display:none!important}
            .main-content{margin:0!important;padding:0!important;width:100%!important}
            .page-heading{margin-bottom:10px}
            .page-heading p{display:none}
            .summary-grid{grid-template-columns:repeat(4,1fr)}
            .summary-card{box-shadow:none}
            .report-panel{box-shadow:none;border:1px solid #ccc}
            .print-only{display:block}
            .report-table th,.report-table td{font-size:9px;padding:6px}
        }
    </style>
</head>
<body class="app-body">

<?php include __DIR__ . '/topbar.php'; ?>
<?php include __DIR__ . '/sideleftbar.php'; ?>

<main class="main-content">

    <div class="page-heading">
        <span class="eyebrow">LAPORAN AKADEMIK</span>
        <h1>Rekap Laporan Mahasiswa</h1>
        <p>Rekap data mahasiswa berdasarkan ruang lingkup akses pengguna.</p>
    </div>

    <?php if (!empty($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= e($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <div class="report-panel filter-panel">
        <div class="report-header">
            <h2>Filter Laporan</h2>
            <p>Scope akses: <span class="scope-badge"><?= e($judul_scope) ?></span></p>
        </div>

        <form method="get" class="filter-form">
            <div class="filter-grid">

                <?php if ($role === 'ADMIN' || $role === 'REKTORAT'): ?>
                <div class="filter-group">
                    <label for="id_fakultas">Fakultas</label>
                    <select name="id_fakultas" id="id_fakultas">
                        <option value="0">-- Semua Fakultas --</option>
                        <?php foreach ($fakultas as $f): ?>
                            <option value="<?= (int)$f['id_fakultas'] ?>"
                                <?= $filter_fakultas === (int)$f['id_fakultas'] ? 'selected' : '' ?>>
                                <?= e($f['kode_fakultas'] . ' - ' . $f['nama_fakultas']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php else: ?>
                    <input type="hidden" name="id_fakultas" value="<?= (int)$filter_fakultas ?>">
                <?php endif; ?>

                <div class="filter-group">
                    <label for="id_program_studi">Program Studi</label>
                    <select name="id_program_studi" id="id_program_studi">
                        <option value="0">-- Semua Program Studi --</option>
                        <?php foreach ($prodi as $p): ?>
                            <option value="<?= (int)$p['id_program_studi'] ?>"
                                <?= $filter_prodi === (int)$p['id_program_studi'] ? 'selected' : '' ?>>
                                <?= e($p['kode_program_studi'] . ' - ' . $p['nama_program_studi']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="filter-group">
                    <label for="status_mahasiswa">Status Mahasiswa</label>
                    <select name="status_mahasiswa" id="status_mahasiswa">
                        <option value="">-- Semua Status --</option>
                        <?php foreach ($statuses as $status): ?>
                            <option value="<?= e($status) ?>" <?= $filter_status === $status ? 'selected' : '' ?>>
                                <?= e($status) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="filter-group">
                    <label for="jenis_kelamin">Jenis Kelamin</label>
                    <select name="jenis_kelamin" id="jenis_kelamin">
                        <option value="">-- Semua --</option>
                        <?php foreach ($jenis_kelamin_options as $key => $label): ?>
                            <option value="<?= e($key) ?>" <?= $filter_jk === $key ? 'selected' : '' ?>>
                                <?= e($label) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="filter-group">
                    <label for="q">Cari NPM / Nama</label>
                    <input type="search" name="q" id="q" value="<?= e($keyword) ?>" maxlength="100"
                           placeholder="Ketik NPM atau nama mahasiswa">
                </div>

            </div>

            <div class="filter-actions no-print">
                <button type="submit" class="btn btn-primary">Tampilkan Laporan</button>
                <a href="laporan_mahasiswa.php" class="btn btn-outline">Reset</a>
                <button type="button" class="btn btn-outline" onclick="window.print()">Cetak</button>
            </div>
        </form>
    </div>

    <div class="summary-grid">
        <div class="summary-card">
            <div class="label">Total Mahasiswa</div>
            <div class="value"><?= number_format($total, 0, ',', '.') ?></div>
        </div>
        <div class="summary-card">
            <div class="label">Laki-laki</div>
            <div class="value"><?= number_format($total_l, 0, ',', '.') ?></div>
        </div>
        <div class="summary-card">
            <div class="label">Perempuan</div>
            <div class="value"><?= number_format($total_p, 0, ',', '.') ?></div>
        </div>
        <div class="summary-card">
            <div class="label">Mahasiswa Aktif</div>
            <div class="value"><?= number_format($total_aktif, 0, ',', '.') ?></div>
        </div>
    </div>

    <div class="report-panel">
        <div class="report-header">
            <h2>Daftar Mahasiswa</h2>
            <p><?= e($judul_scope) ?> · <?= date('d-m-Y H:i') ?></p>
            <div class="print-only" style="margin-top:8px;">
                <strong>Rekap Laporan Mahasiswa</strong><br>
                Dicetak: <?= date('d-m-Y H:i') ?>
            </div>
        </div>

        <div class="report-table-wrap">
            <table class="report-table">
                <thead>
                    <tr>
                        <th class="center">No</th>
                        <th>NPM</th>
                        <th>Nama Mahasiswa</th>
                        <th>Program Studi</th>
                        <th>Fakultas</th>
                        <th class="center">JK</th>
                        <th>Tanggal Masuk</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$rows): ?>
                    <tr>
                        <td colspan="8" class="center">Tidak ada data mahasiswa sesuai filter.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($rows as $index => $row): ?>
                        <tr>
                            <td class="center"><?= $index + 1 ?></td>
                            <td><?= e($row['npm']) ?></td>
                            <td><?= e($row['nama_mahasiswa']) ?></td>
                            <td><?= e($row['kode_program_studi'] . ' - ' . $row['nama_program_studi']) ?></td>
                            <td><?= e($row['kode_fakultas'] . ' - ' . $row['nama_fakultas']) ?></td>
                            <td class="center"><?= e($row['jenis_kelamin']) ?></td>
                            <td><?= e($row['tanggal_masuk']) ?></td>
                            <td><span class="status-badge"><?= e($row['status_mahasiswa']) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="report-footer">
            Menampilkan <strong><?= number_format($total, 0, ',', '.') ?></strong> data mahasiswa.
            <?php if ($total_lulus > 0): ?>
                Jumlah lulusan pada hasil filter: <strong><?= number_format($total_lulus, 0, ',', '.') ?></strong>.
            <?php endif; ?>
        </div>
    </div>

</main>
</body>
</html>
