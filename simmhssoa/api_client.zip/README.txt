PAKET CRUD MAHASISWA - SIM MAHASISWA SOA

Paket mengikuti pola modul Program Studi SOA yang telah berjalan.

1. Salin folder soa/apimahasiswa.php ke htdocs/soa/.
   Pastikan folder soa sudah memiliki koneksi.php yang terhubung ke database sim_mahasiswa.
2. Salin folder simmhssoa/mahasiswa*.php dan api_client.php ke htdocs/simmhssoa/.
   api_client.php disertakan sebagai referensi; jika file tersebut sudah ada dan telah dikonfigurasi, tidak perlu ditimpa.
3. Pastikan auth_check.php, csrf.php, topbar.php, sideleftbar.php, style.css, dan api_client.php tersedia di folder simmhssoa.
4. Akses http://localhost/simmhssoa/mahasiswa.php.

API actions: list, options, detail, create, update, delete.
Endpoint memeriksa request localhost dan akun ADMIN aktif sebagaimana apiprogramstudi.php.
Consumer tidak melakukan koneksi atau query database secara langsung.

CATATAN DESAIN VERSI INI
- CRUD hanya mengelola tabel mahasiswa dan relasi program_studi.
- Pembuatan akun pengguna tidak digabungkan dengan tambah mahasiswa. Kolom id_pengguna diisi NULL.
- Hak akses dibuat sama seperti modul Program Studi: ADMIN.
- Profil mahasiswa, laporan, audit log viewer, dan integrasi akun mahasiswa belum termasuk paket CRUD dasar ini.
- Sebelum digunakan pada server terpisah, mekanisme localhost harus diganti autentikasi antar-server dan HTTPS.
