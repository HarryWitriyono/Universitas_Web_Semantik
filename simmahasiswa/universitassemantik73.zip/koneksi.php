<?php
// Cek apakah aplikasi berjalan di server lokal atau hosting
$is_local = ($_SERVER['SERVER_NAME'] === 'localhost' || $_SERVER['SERVER_NAME'] === '127.0.0.1');

if ($is_local) {
    // --- KONFIGURASI SERVER LOKAL (XAMPP / LARAGON) ---
    $host     = "localhost";
    $username = "root";
    $password = "";
    $dbname   = "universitassemantik";
    $port     = 3306;
} else {
    // --- KONFIGURASI SERVER HOSTING (INFINITYFREE) ---
    $host     = "sql201.infinityfree.com";
    $username = "if0_42995784";
    $password = "XUVBSyh791ObHP";
    $dbname   = "if0_42995784_universitassemantik";
    $port     = 3306;
}

// Membuat koneksi ke database
$koneksi = mysqli_connect($host, $username, $password, $dbname, $port);

// Memeriksa status koneksi
if (!$koneksi) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

// Set charset
mysqli_set_charset($koneksi, "utf8mb4");
?>