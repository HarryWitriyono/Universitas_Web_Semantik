<?php
// Memanggil koneksi database
require_once 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi Manajemen Mahasiswa - Universitas Semantik</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .hero-section {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 90px 0 70px;
            border-bottom-right-radius: 50px;
            border-bottom-left-radius: 50px;
        }
        .card-custom {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card-custom:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 25px rgba(0,0,0,0.12);
        }
        .role-icon {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 28px;
        }
        .bg-mahasiswa { background-color: #e3f2fd; color: #0d6efd; }
        .bg-operator { background-color: #e8f5e9; color: #198754; }
        .bg-admin { background-color: #f3e5f5; color: #9c27b0; }
        .btn-outline-purple {
            color: #9c27b0;
            border-color: #9c27b0;
        }
        .btn-outline-purple:hover {
            background-color: #9c27b0;
            color: white;
        }
        footer {
            background-color: #1a1a1a;
            color: #ccc;
        }
    </style>
</head>
<body>

    <!-- Header / Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-transparent position-absolute w-100">
        <div class="container">
            <a class="navbar-brand fw-bold fs-4" href="#">
                <i class="fa-solid fa-graduation-cap me-2"></i>Universitas Semantik
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link active" href="#beranda">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link" href="#akses">Akses Portal</a></li>
                    <li class="nav-item"><a class="nav-link" href="#informasi">Informasi</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="beranda" class="hero-section text-center">
        <div class="container pt-4">
            <i class="fa-solid fa-university fa-4x mb-3 text-warning"></i>
            <h1 class="display-4 fw-bold">Sistem Informasi Manajemen Mahasiswa</h1>
            <p class="lead max-w-600 mx-auto opacity-90">
                Portal Terpadu Pengelolaan Data Akademik Mahasiswa Per Program Studi Universitas Semantik.
            </p>
            <a href="#akses" class="btn btn-warning btn-lg px-4 mt-3 fw-semibold shadow">
                <i class="fa-solid fa-right-to-bracket me-2"></i>Masuk Portal
            </a>
        </div>
    </section>

    <!-- Access Portal Roles (RBAC) -->
    <section id="akses" class="py-5">
        <div class="container py-4">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Akses Portal Pengguna</h2>
                <p class="text-muted">Pilih jenis portal sesuai dengan peran (role) Anda dalam sistem</p>
            </div>

            <div class="row g-4">
                <!-- Portal Mahasiswa -->
                <div class="col-md-4">
                    <div class="card card-custom h-100 text-center p-4">
                        <div class="card-body">
                            <div class="role-icon bg-mahasiswa">
                                <i class="fa-solid fa-user-graduate"></i>
                            </div>
                            <h4 class="card-title fw-bold">Mahasiswa</h4>
                            <p class="card-text text-muted">Akses biodata profil pribadi, data akademis, dan pencetakan informasi mahasiswa.</p>
                            <a href="login_mahasiswa.php" class="btn btn-outline-primary w-100 rounded-pill mt-3 fw-semibold">
                                Login Mahasiswa <i class="fa-solid fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Portal Operator Prodi -->
                <div class="col-md-4">
                    <div class="card card-custom h-100 text-center p-4">
                        <div class="card-body">
                            <div class="role-icon bg-operator">
                                <i class="fa-solid fa-user-gear"></i>
                            </div>
                            <h4 class="card-title fw-bold">Operator Prodi</h4>
                            <p class="card-text text-muted">Pengelolaan data mahasiswa khusus per Program Studi dan pencetakan rekapitulasi laporan.</p>
                            <a href="login.php?role=operator" class="btn btn-outline-success w-100 rounded-pill mt-3 fw-semibold">
                                Login Operator <i class="fa-solid fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Portal Administrator -->
                <div class="col-md-4">
                    <div class="card card-custom h-100 text-center p-4">
                        <div class="card-body">
                            <div class="role-icon bg-admin">
                                <i class="fa-solid fa-user-shield"></i>
                            </div>
                            <h4 class="card-title fw-bold">Administrator</h4>
                            <p class="card-text text-muted">Kelola seluruh data sistem, manajemen akun pengguna, serta master Fakultas & Prodi.</p>
                            <a href="login.php?role=admin" class="btn btn-outline-purple w-100 rounded-pill mt-3 fw-semibold">
                                Login Admin <i class="fa-solid fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Informational Section -->
    <section id="informasi" class="bg-white py-5 border-top border-bottom">
        <div class="container py-3">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0">
                    <h3 class="fw-bold mb-3"><i class="fa-solid fa-shield-halved text-primary me-2"></i>Keamanan & Akses Terintegrasi</h3>
                    <p class="text-secondary">Sistem Informasi Manajemen Mahasiswa Universitas Semantik dirancang dengan arsitektur <i>Role Based Access Control (RBAC)</i>. Sistem ini membedakan modul serta menu yang dapat diakses pengguna sesuai perannya.</p>
                    <ul class="list-unstyled text-secondary">
                        <li class="mb-2"><i class="fa-solid fa-check-circle text-success me-2"></i> Otentikasi ganda (Tabel `mahasiswa` & Tabel `pengguna`).</li>
                        <li class="mb-2"><i class="fa-solid fa-check-circle text-success me-2"></i> Pengelompokan data spesifik per Program Studi.</li>
                        <li class="mb-2"><i class="fa-solid fa-check-circle text-success me-2"></i> Desain responsif menggunakan Bootstrap 5.</li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <div class="p-4 bg-light rounded-4 border">
                        <h5 class="fw-bold mb-3"><i class="fa-solid fa-circle-info text-warning me-2"></i>Petunjuk Otentikasi</h5>
                        <p class="small text-muted mb-2"><b>Mahasiswa:</b> Masuk dengan memasukkan <u>NPM</u> dan password terdaftar pada tabel mahasiswa.</p>
                        <p class="small text-muted mb-0"><b>Operator & Admin:</b> Masuk dengan menggunakan <u>Username</u> yang telah terdaftar pada tabel pengguna.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="py-4 text-center">
        <div class="container">
            <p class="mb-0 small">&copy; <?php echo date('Y'); ?> Universitas Semantik. All rights reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>