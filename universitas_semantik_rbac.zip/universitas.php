<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
requirePermission('universitas.view');
$pageTitle = 'Universitas';
require __DIR__ . '/partials/header.php';
?>
<div class="page-heading">
  <div>
    <h1>Universitas</h1>
    <p>Halaman profil universitas.</p>
  </div>
</div>
<div class="card">
  <h3>Universitas</h3>
  <p class="empty">Modul ini sudah dilindungi RBAC. Implementasi CRUD/tabel dapat kita lanjutkan pada tahap berikutnya.</p>
</div>
<?php require __DIR__ . '/partials/footer.php'; ?>
