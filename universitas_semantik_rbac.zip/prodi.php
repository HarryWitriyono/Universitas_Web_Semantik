<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
requirePermission('prodi.view');
$pageTitle = 'Program Studi';
require __DIR__ . '/partials/header.php';
?>
<div class="page-heading">
  <div>
    <h1>Program Studi</h1>
    <p>Halaman data program studi dan statistik mahasiswa per prodi.</p>
  </div>
</div>
<div class="card">
  <h3>Program Studi</h3>
  <p class="empty">Modul ini sudah dilindungi RBAC. Implementasi CRUD/tabel dapat kita lanjutkan pada tahap berikutnya.</p>
</div>
<?php require __DIR__ . '/partials/footer.php'; ?>
