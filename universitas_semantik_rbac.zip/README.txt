# Universitas Semantik — Native PHP + MySQLi + RBAC

## Struktur
- index.html              Landing page + login modal
- db.php                  Koneksi MySQLi
- auth.php                Session, RBAC rules, permission guard, audit
- login.php               Autentikasi password_verify()
- logout.php              Logout + audit
- dashboard.php           Dashboard setelah login
- partials/header.php     Sidebar kiri + topbar
- partials/footer.php
- assets/css/dashboard.css
- mahasiswa.php
- prodi.php
- fakultas.php
- universitas.php
- pengguna.php
- audit.php

## Database
Import dump:
`dump_universitas_semantik(1).sql`

Pastikan database bernama:
`universitas_semantik`

## Login awal dari dump
- username: `admin`
- password: `password`

- username: `operator`
- password: `password`

Password diverifikasi dengan `password_verify()` terhadap `pengguna.password_hash`.

## RBAC
Role berasal dari:
- `pengguna.id_role`
- `roles.id_role`
- `roles.nama_role`

Permission rule sementara berada di `auth.php` agar tidak perlu menambah tabel baru.
Setiap halaman memanggil `requirePermission('permission.nama')`, sehingga menyembunyikan menu saja tidak menjadi satu-satunya proteksi.

## Catatan
Untuk produksi, ubah DB credential di `db.php`, gunakan HTTPS, cookie session Secure/HttpOnly/SameSite, dan pertimbangkan memindahkan RBAC rules ke tabel permission jika kebutuhan otorisasi semakin kompleks.
