<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
requirePermission('fakultas.view');
$pageTitle = 'Fakultas';
require __DIR__ . '/partials/header.php';
?>
<div class="page-heading">
  <div>
    <h1>Fakultas</h1>
    <p>Halaman data fakultas.</p>
  </div>
</div>
<div class="card">
  <h3>Fakultas</h3>
  <p class="empty">Modul ini sudah dilindungi RBAC. Implementasi CRUD/tabel dapat kita lanjutkan pada tahap berikutnya.</p>
</div>
<?php require __DIR__ . '/partials/footer.php'; ?>
