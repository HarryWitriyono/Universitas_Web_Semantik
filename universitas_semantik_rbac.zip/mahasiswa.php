<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
requirePermission('mahasiswa.view');
$pageTitle = 'Mahasiswa';
require __DIR__ . '/partials/header.php';
?>
<div class="page-heading">
  <div>
    <h1>Mahasiswa</h1>
    <p>Halaman pengelolaan data mahasiswa. CRUD dapat dikembangkan pada modul ini.</p>
  </div>
</div>
<div class="card">
  <h3>Mahasiswa</h3>
  <p class="empty">Modul ini sudah dilindungi RBAC. Implementasi CRUD/tabel dapat kita lanjutkan pada tahap berikutnya.</p>
</div>
<?php require __DIR__ . '/partials/footer.php'; ?>
