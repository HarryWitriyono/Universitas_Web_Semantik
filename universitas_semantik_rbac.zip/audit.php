<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
requirePermission('audit.view');
$pageTitle = 'Audit Log';
require __DIR__ . '/partials/header.php';
?>
<div class="page-heading">
  <div>
    <h1>Audit Log</h1>
    <p>Halaman forensic readiness untuk melihat aktivitas pengguna.</p>
  </div>
</div>
<div class="card">
  <h3>Audit Log</h3>
  <p class="empty">Modul ini sudah dilindungi RBAC. Implementasi CRUD/tabel dapat kita lanjutkan pada tahap berikutnya.</p>
</div>
<?php require __DIR__ . '/partials/footer.php'; ?>
