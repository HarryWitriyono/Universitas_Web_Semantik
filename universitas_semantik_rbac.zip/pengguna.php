<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
requirePermission('pengguna.view');
$pageTitle = 'Pengguna';
require __DIR__ . '/partials/header.php';
?>
<div class="page-heading">
  <div>
    <h1>Pengguna</h1>
    <p>Halaman manajemen pengguna dan role. Hanya admin yang dapat mengelola pengguna.</p>
  </div>
</div>
<div class="card">
  <h3>Pengguna</h3>
  <p class="empty">Modul ini sudah dilindungi RBAC. Implementasi CRUD/tabel dapat kita lanjutkan pada tahap berikutnya.</p>
</div>
<?php require __DIR__ . '/partials/footer.php'; ?>
